import random
import inputData
def FirstGen(cityCoord):
    return random.sample(cityCoord,inputData.noOfCities)
    